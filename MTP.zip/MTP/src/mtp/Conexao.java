package mtp;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.Date;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/**
 *
 * @author ifg
 */
public class Conexao {

    private String url = "jdbc:postgresql://localhost/mtp";

    private String usuario = "postgres";

    private String senha = "postgres";

    private Connection conn;

    public Conexao() {
        conectar();
    }

    public void conectar() {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }

        Properties props = new Properties();
        props.setProperty("user", this.usuario);
        props.setProperty("password", this.senha);

        try {
            this.conn = DriverManager.getConnection(this.url, props);
        } catch (SQLException e) {
            e.getMessage();
        }
    }

    public Connection getConnection() {
        return this.conn;
    }

    /**
     * Método que cria a tabela pessoa para este exemplo.
     *
     * Normalmente, a criação de tabelas NÃO é feita pela aplicação.
     */
    public void criarTabela() {
        try {
            PreparedStatement st = this.conn.prepareStatement("CREATE TABLE pessoa (id serial primary key, nome text)");
            st.execute();
            st.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método que insere uma pessoa no banco de dados
     *
     * Por enquanto, a pessoa está fixa!
     */
    public void inserir() {
        try {
            PreparedStatement st = this.conn.prepareStatement("INSERT INTO pessoa (nome) VALUES (?)");
            st.setString(1, "Larissa");
            st.executeUpdate();
            st.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método que atualiza todos os nomes do banco de dados
     *
     * E se for necessário alterar para uma pessoa só? O que muda?
     */
    public void atualizar() {
        try {
            PreparedStatement st = this.conn.prepareStatement("UPDATE pessoa SET nome = ?");
            st.setString(1, "Larissa 2"
                    + "");
            st.executeUpdate();
            st.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método que exclui uma determinada pessoa do banco de dados
     *
     * Está sempre excluindo a mesma pessoa! A que tem ID = 1!
     */
    public void excluir() {
        try {
            PreparedStatement st = this.conn.prepareStatement("DELETE FROM pessoa WHERE id = ?");
            st.setInt(1, 1);
            st.executeUpdate();
            st.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Usuario login(String email, String senha) {
        try {
            PreparedStatement ps = this.conn
                    .prepareStatement("SELECT id, nome, email, senha, local FROM pessoa WHERE email = ? AND senha = ?;");
            ps.setString(1, email);
            ps.setString(2, senha);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Usuario us = new Usuario();
                us.setId(rs.getInt(1));
                us.setNome(rs.getString(2));
                us.setEmail(rs.getString(3));
                us.setSenha(rs.getString(4));
                us.setLocal(rs.getString(5));

                return us;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.getMessage();
            return null;
        }
    }

    public void cadastrar(String nome, String email, String local, String senha) throws SQLException {
        PreparedStatement st = this.conn.prepareStatement("INSERT INTO pessoa (nome, email, local, senha) VALUES (?, ?, ?, ?)");
        st.setString(1, nome);
        st.setString(2, email);
        st.setString(3, local);
        st.setString(4, senha);
        st.executeUpdate();
        st.close();

    }

    public Usuario atualizar(String nome, String local, String senha, Integer id, String email) {
        Usuario usr = new Usuario();

        try {
            PreparedStatement st = this.conn.prepareStatement("UPDATE pessoa SET (nome, local, senha) = (?, ?, ?) WHERE id = ?;");
            st.setString(1, nome);
            st.setString(2, local);
            st.setString(3, senha);
            st.setInt(4, id);
            st.executeUpdate();
            st.close();

            usr.setId(id);
            usr.setEmail(email);
            usr.setLocal(local);
            usr.setNome(nome);
            usr.setSenha(senha);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return usr;
    }

    public void salvarArquivoNoBd(int id_pessoa, String texto, File imagem, Date data) throws FileNotFoundException, IOException {

        try {
            // inputStream com o arquivo selecionado
            FileInputStream fis = new FileInputStream(imagem);

            // cria a consulta
            PreparedStatement ps = this.conn.prepareStatement("INSERT INTO post (id_pessoa, texto, imagem, data) VALUES (?, ?, ?, ?)");
            ps.setInt(1, id_pessoa);
            ps.setString(2, texto);
            ps.setBinaryStream(3, fis, (int) imagem.length());
            ps.setDate(4, data);

            // salva no banco de dados
            ps.executeUpdate();

            // fecha a consulta e o inputStream para agilizar a liberação de recursos do computador
            ps.close();
            fis.close();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Post> buscarPost(int id) {

        try {
            PreparedStatement ps = this.conn.prepareStatement("SELECT id, id_pessoa, texto, imagem, data FROM post WHERE id_pessoa = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            

            Scanner in = new Scanner(System.in);
            ArrayList<Post> post = new ArrayList();
            System.out.println(rs.next());
            while (rs.next()) {

                Post pt = new Post();
                pt.setId_pessoa(rs.getInt("id_pessoa"));
                pt.setTexto(rs.getString("texto"));
                pt.setImagem(rs.getBytes("imagem"));
                pt.setData(rs.getDate("data"));
                post.add(pt);

            }
            return post;
        } catch (SQLException e) {
            e.getMessage();
            return null;
        }
    }
}

/*SELECT count(id)
FROM like_post
GROUP BY id_pessoa, id_post*/