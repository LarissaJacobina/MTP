
import java.awt.Frame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author ifg
 */
public class frame extends Frame {

    public frame(String primeiro_Frame) {
    }

    public static void main(String[] args) {
        Frame frame = new frame("Primeiro Frame");
        frame.setSize(500,500);
        frame.setVisible(true);
        frame.setLocation(200, 150);
    }
}

